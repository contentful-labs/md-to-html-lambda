'use strict';

var _contentful = require('contentful');

exports.handler = function (event, context) {
  event.entryId;
};

