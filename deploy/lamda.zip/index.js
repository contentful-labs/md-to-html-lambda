import {createClient} from 'contentful'

exports.handler = function (event, context) {
  event.entryId
}
